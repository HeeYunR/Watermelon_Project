desc tblMember;
select * from tblMember order by mem_seq desc;

delete from tblMember where mem_seq=601;
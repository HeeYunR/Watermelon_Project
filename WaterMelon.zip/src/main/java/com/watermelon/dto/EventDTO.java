package com.watermelon.dto;

public class EventDTO {
	
	private String event_seq;
	private String prize;
	private String event_date;
	
	
	public String getEvent_seq() {
		return event_seq;
	}
	public void setEvent_seq(String event_seq) {
		this.event_seq = event_seq;
	}
	public String getPrize() {
		return prize;
	}
	public void setPrize(String prize) {
		this.prize = prize;
	}
	public String getEvent_date() {
		return event_date;
	}
	public void setEvent_date(String event_date) {
		this.event_date = event_date;
	}
	
	
	

}

package com.watermelon.dto;

public class ConcertDTO {
	
	private String con_seq;
	private String title;
	private String place;
	private String start_date;
	private String end_date;
	private String region_seq;
	private String genre_seq;
	
	
	public String getCon_seq() {
		return con_seq;
	}
	public void setCon_seq(String con_seq) {
		this.con_seq = con_seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getRegion_seq() {
		return region_seq;
	}
	public void setRegion_seq(String region_seq) {
		this.region_seq = region_seq;
	}
	public String getGenre_seq() {
		return genre_seq;
	}
	public void setGenre_seq(String genre_seq) {
		this.genre_seq = genre_seq;
	}
	
	
	

}

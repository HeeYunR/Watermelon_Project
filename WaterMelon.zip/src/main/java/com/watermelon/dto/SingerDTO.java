package com.watermelon.dto;

public class SingerDTO {
	
	private String singer_seq;
	private String type;
	private String name;
	private String member;
	
	public String getSinger_seq() {
		return singer_seq;
	}
	public void setSinger_seq(String singer_seq) {
		this.singer_seq = singer_seq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
	
	

}

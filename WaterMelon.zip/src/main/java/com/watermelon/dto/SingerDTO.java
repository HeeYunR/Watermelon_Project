package com.watermelon.dto;

import lombok.Data;

@Data
public class SingerDTO {
	
	private String singer_seq;
	private String type;
	private String name;
	private String member;
	

}

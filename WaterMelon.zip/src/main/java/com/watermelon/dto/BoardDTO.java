package com.watermelon.dto;

import lombok.Data;

@Data
public class BoardDTO {
	
	private String board_seq;
	private String title;
	private String content;
	private String q_file;
	private String ans_yn;
	private String q_date;
	private String mem_seq;

}

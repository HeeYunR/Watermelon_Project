package com.watermelon.dto;

public class MemberDTO {
	
	private String mem_seq;
	private String id;
	private String nickname;
	private String pw;
	private String name;
	private String ssn;
	private String tel;
	
	
	public String getMem_seq() {
		return mem_seq;
	}
	public void setMem_seq(String mem_seq) {
		this.mem_seq = mem_seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
	
	

}

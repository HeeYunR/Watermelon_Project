package com.watermelon.dto;

import lombok.Data;

@Data
public class MemberDTO {
	
	private String mem_seq;
	private String id;
	private String nickname;
	private String pw;
	private String name;
	private String ssn;
	private String tel;
	
}

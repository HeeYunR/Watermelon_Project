package com.watermelon.dto;

import lombok.Data;

@Data
public class AdminDTO {
	
	private final String ADMIN1ID = "admin1";
	private final String ADMIN2ID = "admin2";
	private final String ADMIN3ID = "admin3";
	
	private final String ADMINPW = "admin123";

	

	
}

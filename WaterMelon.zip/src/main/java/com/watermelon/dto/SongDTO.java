package com.watermelon.dto;

public class SongDTO {
	
	private String song_seq;
	private String title;
	private String year;
	private String composer;
	private String writer;
	private String lyric;
	private String likes;
	private String genre_seq;
	private String singer_seq;
	
	
	public String getSong_seq() {
		return song_seq;
	}
	public void setSong_seq(String song_seq) {
		this.song_seq = song_seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getComposer() {
		return composer;
	}
	public void setComposer(String composer) {
		this.composer = composer;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getLyric() {
		return lyric;
	}
	public void setLyric(String lyric) {
		this.lyric = lyric;
	}
	public String getLikes() {
		return likes;
	}
	public void setLikes(String likes) {
		this.likes = likes;
	}
	public String getGenre_seq() {
		return genre_seq;
	}
	public void setGenre_seq(String genre_seq) {
		this.genre_seq = genre_seq;
	}
	public String getSinger_seq() {
		return singer_seq;
	}
	public void setSinger_seq(String singer_seq) {
		this.singer_seq = singer_seq;
	}
	
	
	

}

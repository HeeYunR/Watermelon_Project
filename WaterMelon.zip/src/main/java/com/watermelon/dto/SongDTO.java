package com.watermelon.dto;

import lombok.Data;

@Data
public class SongDTO {
	
	private String song_seq;
	private String title;
	private String year;
	private String composer;
	private String writer;
	private String lyric;
	private String likes;
	private String genre_seq;
	private String singer_seq;
	

	

}

package com.watermelon.controller;

import java.util.Scanner;

import com.watermelon.service.BoardService;
import com.watermelon.service.ConSearchService;
import com.watermelon.service.DJService;
import com.watermelon.service.MemEditService;
import com.watermelon.service.MemLikeService;
import com.watermelon.service.MemOutService;
import com.watermelon.service.MemPlistService;
import com.watermelon.service.RankSearchService;
import com.watermelon.service.SongSearchService;

public class MemHomeController {
	
	public static void MemHome() {
		//회원용 홈화면
		System.out.println("회원용 홈화면");
		
Scanner scan = new Scanner(System.in);
		
		boolean loop = true;
		
		while(loop) {
			System.out.println();
			System.out.print("(회원홈)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {
				
				//회원정보 수정
				MemEditService.memEdit();
				
				
			} else if (str.equals("2")) {
				
				//노래 검색
				SongSearchService.songSearch();
				
				
			} else if (str.equals("3")) {
				//랭킹 조회(좋아요 순) > 차트
				RankSearchService.rankSearch();
				
			} else if (str.equals("4")) {
				//재생목록 등록/조회/삭제
				MemPlistService.plistMain();
				
			} else if (str.equals("5")) {
				//좋아요 목록 조회/삭제
				MemLikeService.likeMain();
				
			} else if (str.equals("6")) {
				//추천곡 조회
				MemRlistController.rlistMain();
				
			} else if (str.equals("7")) {
				//장르별 노래 조회
				SongSearchService.genreSearch();
				
			} else if (str.equals("8")) {
				//콘서트 조회
				ConSearchService.conSearch();
				
			} else if (str.equals("9")) {
				//회원 탈퇴
				MemOutService.out();
				
			} else if (str.equals("10")) {
				//게시판 조회
				BoardService.boardMain();
				
			} else if (str.equals("11")) {
				//DJ 조회
				DJService.djMain();

			} else if (str.equals("0")) {
				loop = false;
				//프로그램 종료
				System.out.println("프로그램 종료");
				
			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}
			
		}
		
		
		
	}
	
	
	
	
	

}

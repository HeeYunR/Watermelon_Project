package com.watermelon.controller;

import java.util.Scanner;

import com.watermelon.service.BoardManageService;
import com.watermelon.service.ConManageService;
import com.watermelon.service.EventManageService;
import com.watermelon.service.GenreSearchService;
import com.watermelon.service.SongManageService;

public class AdminHomeController {

	public static void AdminHome() {
		// 관리자용 홈화면
		System.out.println("관리자용 홈화면");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.println("1. 회원 관리");
			System.out.println("2. 노래 관리");
			System.out.println("3. 장르 관리");
			System.out.println("4. 콘서트 관리");
			System.out.println("5. 게시판 관리");
			System.out.println("6. 이벤트 관리");
			System.out.println("0. 프로그램 종료");
			System.out.print("(관리자홈)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 회원 관리
				MemManageController.memMain();

			} else if (str.equals("2")) {

				// 노래 CRUD
				SongManageService.songMain();

			} else if (str.equals("3")) {
				// 장르 조회
				GenreSearchService.genreMain();
				
			} else if (str.equals("4")) {
				// 콘서트 CRUD
				ConManageService.conMain();

			} else if (str.equals("5")) {
				// 게시판 CRUD
				BoardManageService.boardMain();

			} else if (str.equals("6")) {
				// 이벤트 CRUD
				EventManageService.eventMain();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");
				//문제 : 프로그램 종료 시 로그인 화면의 loop를 빠져나오기 때문에 
				//"로그인에 최종 실패하셨습니다. 5분 간 로그인을 시도할 수 없습니다." 메시지가 출력됨

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}

	}
}

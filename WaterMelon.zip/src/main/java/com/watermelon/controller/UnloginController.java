package com.watermelon.controller;

import java.util.Scanner;

import com.watermelon.service.BoardService;
import com.watermelon.service.ConSearchService;
import com.watermelon.service.RankSearchService;
import com.watermelon.service.SongSearchService;

public class UnloginController {
	
	public static void unlogin_home() {
		//비회원용 홈화면
		System.out.println("비회원용 홈화면");
		
		Scanner scan = new Scanner(System.in);
		
		boolean loop = true;
		
		while(loop) {
			System.out.println();
			System.out.print("(비회원홈)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {
				
				//노래 검색
				SongSearchService.songSearch();
				
				
			} else if (str.equals("2")) {
				
				//랭킹 검색
				RankSearchService.rankSearch();
				
			} else if (str.equals("3")) {
				//콘서트 조회
				ConSearchService.conSearch();
				
			} else if (str.equals("4")) {
				//게시판 조회
				BoardService.boardMain();
				
			} else if (str.equals("0")) {
				loop = false;
				//프로그램 종료
				System.out.println("프로그램 종료");
				
			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}
			
		}
		
		
	}

}

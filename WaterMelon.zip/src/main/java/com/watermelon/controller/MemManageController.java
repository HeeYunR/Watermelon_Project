package com.watermelon.controller;

import java.util.Scanner;

import com.watermelon.service.MemDeleteService;
import com.watermelon.service.MemSearchService;

public class MemManageController {

	public static void memMain() {

		System.out.println("관리자_회원 관리");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(관회)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 회원 조회
				MemSearchService.memSearch();

			} else if (str.equals("2")) {

				// 회원 삭제
				MemDeleteService.memDelete();

			} else if (str.equals("3")) {
				// 관리자용 홈화면으로 돌아가기
				break;
				
			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}
		
		
	}
	
	

}

package com.watermelon.controller;

import java.util.Scanner;

import com.watermelon.service.RListService;

public class MemRlistController {

	public static void rlistMain() {
		System.out.println("회원_추천곡 조회");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(회추)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 장르별 추천곡
				RListService.genreSearch();

			} else if (str.equals("2")) {

				// 가수별 추천곡
				RListService.singerSearch();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}
		
	}

}

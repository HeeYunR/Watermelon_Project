package com.watermelon.board;

public class BoardManageService {

	public static void boardMain() {
		// 관리자용 게시판 관리
		
		//게시판 글 조회
		
		//게시판 글 삭제
		
		//답글 등록
		
		//답글 수정
		
		//답글 삭제
		
		//답글 조회
		
		
		
	}

}

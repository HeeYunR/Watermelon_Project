package com.watermelon.board;

public class BoardService {

	public static void boardMain() {
		// 게시판 메인
		// 비회원은 게시판 글 조회(전체공개용)만 가능
		// 로그인 시 static으로 int 값을 부여해서, 해당 값이 있는 경우는 로그인 한 것이라 침
		
		
		// 게시판 글 조회
		
			// 공개여부 설정
		
		// 게시판 글 등록
		
		// 게시판 글 수정
		
		// 게시판 글 삭제
		
		// 답글 조회
		
	}

}

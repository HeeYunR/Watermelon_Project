package com.watermelon.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/molar.do")
public class SongManageService extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//SongManageService.java
		//관리자_노래관리

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/molar.jsp");
		dispatcher.forward(req, resp);

	}

}
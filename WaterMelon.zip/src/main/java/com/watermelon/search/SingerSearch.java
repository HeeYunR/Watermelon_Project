package com.watermelon.search;

public class SingerSearch {

}

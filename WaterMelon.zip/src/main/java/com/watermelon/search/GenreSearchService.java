package com.watermelon.search;

import java.util.Scanner;

public class GenreSearchService {

	public static void genreMain() {

		System.out.println("장르 조회");

		Scanner scan = new Scanner(System.in);

		System.out.println("발라드");
		System.out.println("댄스");
		System.out.println("POP");
		System.out.println("트로트");
		System.out.println("인디");
		System.out.println("락");
		System.out.println("OST");
		System.out.println("힙합");
		System.out.println("기타");

	}

}

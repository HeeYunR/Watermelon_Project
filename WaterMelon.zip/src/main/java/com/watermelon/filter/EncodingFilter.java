package com.watermelon.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class EncodingFilter implements Filter {
	
	//체인 끼워넣을 때 web.xml 사용

	
	private String encoding;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
		//필터가 생성될 때 실행
		//System.out.println("필터 생성");
		
		this.encoding = filterConfig.getInitParameter("encoding");
		
		if (this.encoding == null || this.encoding.equals("")) {
			this.encoding = "UTF-8";
		}
		
	}
	
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// 필터가 동작할 때 실행 > 가장 많이 사용
		System.out.println("필터 동작");
	
		//브라우저에서 서버에 실행 요청 시 > filter를 거쳐서 실행하기 때문에 인코딩 처리를 해주면 자동으로 인코딩 작동
		
		//인코딩 처리
		//request.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding(this.encoding);
		
		//자바 > compile하면 수정(X)
		//XML > compile해도 수정 가능
		
		//그 다음 필터를 호출 or 서블릿 호출
		chain.doFilter(request, response); 	
		
		//이제 다른곳에서 인코딩 할 필요 없음
		
	}
	
	
	@Override
	public void destroy() {
		// 필터가 소멸될 때 실행
		System.out.println("필터 소멸");
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

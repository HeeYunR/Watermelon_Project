package com.watermelon.unlogin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.watermelon.dao.WatermelonDAO;
import com.watermelon.dto.MemberDTO;

@WebServlet("/register.do")
public class Resister extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//Resister.java
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/register.jsp");
		dispatcher.forward(req, resp);

	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		String name = req.getParameter("name");
		String nickname = req.getParameter("nickname");
		String ssn = req.getParameter("ssn");
		String tel = req.getParameter("tel");
		
		
		//포장
		MemberDTO dto = new MemberDTO();
		dto.setId(id);
		dto.setPw(pw);
		dto.setName(name);
		dto.setNickname(nickname);
		dto.setSsn(ssn);
		dto.setTel(tel);
		
		WatermelonDAO dao = new WatermelonDAO();
		
		int result = dao.register(dto);
		
		if (result == 1) {
			
			resp.sendRedirect("/watermelon/index.do");
			
		} else {
			
			PrintWriter writer = resp.getWriter();
			writer.print("<script>alert('failed');</script>");
			writer.close();
			
		}
		
		
	}

}
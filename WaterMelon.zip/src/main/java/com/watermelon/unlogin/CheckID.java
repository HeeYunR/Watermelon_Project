package com.watermelon.unlogin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.watermelon.dao.WatermelonDAO;
import com.watermelon.dto.MemberDTO;

@WebServlet("/watermelon/register.do")
public class CheckID extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//CheckID.java
		
		String id = req.getParameter("id");
		
		
		if (id != null && !id.equals("")) {
			
			WatermelonDAO dao = new WatermelonDAO();
			
			int result = dao.checkId(id);
			
			//아이디를 넘기면 
			req.setAttribute("result", result);  	//JSP에게 넘겨줌
			req.setAttribute("id", id);
			
			
		} else {
			
		}
		
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/register.jsp");
		dispatcher.forward(req, resp);

	}

}
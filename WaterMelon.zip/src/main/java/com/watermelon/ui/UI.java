package com.watermelon.ui;

public class UI {
	
	public static void main(String[] args) {
		
		//UI
		
		
		
		
	}

}

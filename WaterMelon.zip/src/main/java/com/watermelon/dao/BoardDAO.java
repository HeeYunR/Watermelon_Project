package com.watermelon.dao;

public class BoardDAO {

}

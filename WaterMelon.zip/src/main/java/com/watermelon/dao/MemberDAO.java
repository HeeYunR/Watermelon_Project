package com.watermelon.dao;

import com.watermelon.dto.MemberDTO;

public class MemberDAO {
	
	
	
	//DB로부터 한 줄 씩 읽어오기

}

package com.watermelon.dao;

public class EventDAO {

}

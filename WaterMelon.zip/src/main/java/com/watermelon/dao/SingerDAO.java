package com.watermelon.dao;

public class SingerDAO {

}

package com.watermelon.dao;

public class AdminDAO {
	
	private final String ADMIN1ID = "admin1";
	private final String ADMIN2ID = "admin2";
	private final String ADMIN3ID = "admin3";
	
	private final String ADMINPW = "admin123";

	public String getADMIN1ID() {
		return ADMIN1ID;
	}

	public String getADMIN2ID() {
		return ADMIN2ID;
	}

	public String getADMIN3ID() {
		return ADMIN3ID;
	}

	public String getADMINPW() {
		return ADMINPW;
	}

	
}

package com.watermelon.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.watermelon.mylib.DBUtil2;
import com.watermelon.dto.MemberDTO;

public class WatermelonDAO {
	
	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	private ResultSet rs;

	public WatermelonDAO() {
		
		this.conn = DBUtil2.open();

	}

	public MemberDTO checkMem(MemberDTO dto) {

		try {
			
			String sql = "select * from tblMember where id = ? and pw = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getId());
			pstat.setString(2, dto.getPw());
			
			rs = pstat.executeQuery();
			
			if (rs.next()) {
				
				MemberDTO result = new MemberDTO();
				result.setId(rs.getString("id"));
				result.setPw(rs.getString("pw"));
				
				return result;
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public int register(MemberDTO dto) {

		try {
		
			String sql = "insert into tblMember(mem_seq, id, nickname, pw, name, ssn, tel) values((select max(mem_seq) + 1 from tblMember), ?, ?, ?, ?, ?, ?)";
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, dto.getId());
			pstat.setString(2, dto.getNickname());
			pstat.setString(3, dto.getPw());
			pstat.setString(4, dto.getName());
			pstat.setString(5, dto.getSsn());
			pstat.setString(6, dto.getTel());
			
			
			return pstat.executeUpdate();	//성공여부 > 성공하면 1, 아니면 0
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}

	public int checkId(String id) {
		// 아이디 중복검사
		try {

			String sql = "select * from tblMember where id = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			
			return pstat.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}

	
	

}

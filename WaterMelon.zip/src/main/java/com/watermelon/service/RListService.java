package com.watermelon.service;

public class RListService {

	//추천곡 서비스
	
	public static void genreSearch() {
		// 장르별 검색
		
	}

	public static void singerSearch() {
		// 가수별 검색
		
	}

}

package com.watermelon.service;

public class UnloginService {
	
	public static void unlogin() {
		
		//비회원
		System.out.println("당신은 비회원입니다.");
		

		
	}

}

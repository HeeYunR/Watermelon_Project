package com.watermelon.service;

public class EventService {

}

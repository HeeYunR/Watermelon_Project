package com.watermelon.service;

import java.util.Scanner;

public class SongManageService {

	public static void songMain() {
		
		System.out.println("관리자_노래 관리");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(관노)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 노래 전체 조회
				SongSearchService.songSearch();

			} else if (str.equals("2")) {

				// 노래 수정
				songEdit();

			} else if (str.equals("3")) {
				// 노래 삭제
				songDelete();
				
			} else if (str.equals("4")) {
				// 노래 등록
				songResiter();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}
		
	}

	//노래 등록
	private static void songResiter() {
		// TODO Auto-generated method stub
		
	}

	//노래 삭제
	private static void songDelete() {
		// TODO Auto-generated method stub
		
	}

	//노래 수정
	private static void songEdit() {
		// TODO Auto-generated method stub
		
	}
	
	

}

package com.watermelon.service;

import java.util.Scanner;

public class MemLikeService {

	public static void likeMain() {
		System.out.println("회원_좋아요 목록 관리");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(회좋)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 좋아요 목록 조회
				search();

			} else if (str.equals("2")) {

				// 좋아요 삭제
				delete();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}
		
	}

	private static void delete() {
		// TODO Auto-generated method stub
		
	}

	private static void search() {
		// TODO Auto-generated method stub
		
	}

}

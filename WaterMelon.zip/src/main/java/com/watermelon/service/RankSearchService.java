package com.watermelon.service;

public class RankSearchService {
	
	public static void rankSearch() {
		
		System.out.println("랭킹 조회용");
		
	}

}

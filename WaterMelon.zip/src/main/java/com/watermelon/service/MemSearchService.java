package com.watermelon.service;

public class MemSearchService {

	public static void memSearch() {


		System.out.println("관리자_회원조회용");
		
	}
	
	

}

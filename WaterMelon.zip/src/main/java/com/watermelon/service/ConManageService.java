package com.watermelon.service;

import java.util.Scanner;

public class ConManageService {

	public static void conMain() {


		System.out.println("관리자_콘서트 관리");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(관콘)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 콘서트 전체조회
				ConSearchService.conSearch();

			} else if (str.equals("2")) {

				// 콘서트 수정
				conEdit();

			} else if (str.equals("3")) {
				// 콘서트 삭제
				conDelete();
				
			} else if (str.equals("3")) {
				// 콘서트 등록
				conResister();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}
		
	}

	//콘서트 등록
	private static void conResister() {
		// TODO Auto-generated method stub
		
	}

	//콘서트 삭제
	private static void conDelete() {
		// TODO Auto-generated method stub
		
	}

	//콘서트 수정
	private static void conEdit() {
		// TODO Auto-generated method stub
		
	}
	
	


}

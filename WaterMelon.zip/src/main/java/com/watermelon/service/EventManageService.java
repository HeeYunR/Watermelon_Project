package com.watermelon.service;

public class EventManageService {

	public static void eventMain() {
		// 이벤트 메인
		
//		이벤트 자동구현? 매달 좋아요 수 1등인 DJ만 선물
//		관리자가 여기서 할 건 당첨 DJ 확인 및 이벤트 경품 수정 정도?
		
	}

}

package com.watermelon.service;

public class ConSearchService {
	
	//콘서트 조회
	public static void conSearch() {
	
		System.out.println("콘서트 조회용");
		
	}

}

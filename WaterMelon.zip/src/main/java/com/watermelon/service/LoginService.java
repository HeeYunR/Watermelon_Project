package com.watermelon.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.watermelon.dao.WatermelonDAO;
import com.watermelon.dto.MemberDTO;

@WebServlet("/loginService.do")
public class LoginService extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//LoginService.java

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/login.jsp");
		dispatcher.forward(req, resp);

	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id = req.getParameter("id");	//<input>에 사용한 name값을 가져오기
		String pw = req.getParameter("pw");
		

		//포장
		MemberDTO dto = new MemberDTO();
		dto.setId(id);
		dto.setPw(pw);
		
		//DAO에게 인증 요청
		WatermelonDAO dao = new WatermelonDAO();
		
		//새로 DTO 꾸려서 dao메소드 호출 > 인증 요청
		//이 result는 dao에서 return 해 준 result임
		MemberDTO result = dao.checkMem(dto);
		
		System.out.println(result);
		
		if (result != null ) {	//로그인 성공(select문에 일치하는 id, pw 있음)
			//session 주기
			req.getSession().setAttribute("id", id);
			
			resp.sendRedirect("/watermelon/index.do");
			
			
		} else {	//로그인 실패
			//이전 페이지로 보내기
			PrintWriter writer = resp.getWriter();
			writer.print("<script>"
					+ "		alert('failed'); "
					+ "		history.back();"
					+ "   </script>");	//print 안의 내용은 JSP가 된 것
			writer.close();
		}
		
		
		
	}

}
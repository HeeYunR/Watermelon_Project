package com.watermelon.service;

import java.util.Scanner;

import com.sun.tools.javac.Main;
import com.watermelon.controller.AdminHomeController;
import com.watermelon.controller.MemHomeController;

public class LoginService {

	// 로그인 화면

	public static void login() {

		System.out.println("아이디와 비밀번호를 입력하시오.");
		Scanner scan = new Scanner(System.in);

		int sido = 0;

		// 로그인 완료하면 홈 화면(회원 화면 / 관리자 화면)
		while (sido < 6) {
			System.out.print("아이디: ");
			String id = scan.nextLine();
			// id 유효성 검사 메소드

			System.out.print("비밀번호: ");
			String pw = scan.nextLine();
			// pw 유효성 검사 메소드

			if (login(id, pw) == 1) {
				// 관리자 홈 화면
				AdminHomeController.AdminHome();
				break;

			} else if (login(id, pw) == 2) {
				// 회원 홈 화면
				MemHomeController.MemHome();
				break;
				
			} else {
				// 로그인 실패
				System.out.println("올바른 아이디와 비밀번호를 입력하십시오.");
				sido++;
			}

		}
		
		if (sido > 5) {
			// 메인으로 돌아가기
			System.out.println("로그인에 최종 실패하셨습니다. 5분 간 로그인을 시도할 수 없습니다.");
			
		} else {
			System.out.println("프로그램을 종료합니다.");
		}


		

	}

	// 유효성 검사 메소드
	public static int login(String id, String pw) {

		// 배열이나 set에 넣어서 hasElement로 하면 될 수도
		if (id.equals("admin") && pw.equals("admin123")) {
			// 관리자
			return 1;

		} else {
			// 회원 or 비회원

			if (id.equals("test") && pw.equals("test")) {

				return 2;

			} else {

				return 3;

			}

		}

	}

}

package com.watermelon.service;

public class ResisterService {
	
	//회원가입
	
	public static void resister() {
		
		System.out.println("회원가입 하십시오.");
		
	}
	
	
	
	

}

package com.watermelon.service;

import java.util.Scanner;

public class MemPlistService {

	public static void plistMain() {
		// 회원용 재생목록 조회/삭제

		System.out.println("회원_재생목록 조회/삭제");

		Scanner scan = new Scanner(System.in);

		boolean loop = true;

		while (loop) {
			System.out.println();
			System.out.print("(회재)원하는 메뉴를 입력하시오: ");
			String str = scan.nextLine();
			if (str.equals("1")) {

				// 재생목록 조회
				search();

			} else if (str.equals("2")) {
				// 재생목록 등록
				make();

			} else if (str.equals("3")) {

				// 재생목록 삭제
				delete();

			} else if (str.equals("0")) {
				loop = false;
				// 프로그램 종료
				System.out.println("프로그램 종료");

			} else {
				System.out.println("정확한 메뉴 번호를 입력하시오.");
				continue;
//				delay
			}

		}

	}

	//생성
	private static void make() {
		
		
	}

	// 조회
	public static void search() {

	}

	// 삭제
	public static void delete() {

	}

}

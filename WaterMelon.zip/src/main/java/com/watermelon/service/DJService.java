package com.watermelon.service;

public class DJService {

	public static void djMain() {
		// DJ
		
	}

}

package com.watermelon.service;

import java.util.Scanner;

public class MemEditService {

	public static void memEdit() {
		// 회원정보 수정
		System.out.println("1. 이름");
		System.out.println("2. 닉네임");
		System.out.println("3. 전화번호");
		System.out.println("4. 생년월일");
		System.out.println("0. 프로그램 종료");
		
		
		System.out.println("수정할 정보를 선택하십시오: ");
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		
		if (str.equals("1")) {
			
			
			
			
		} else if (str.equals("2")) {
			
			
		}
		
		
		
	}

}

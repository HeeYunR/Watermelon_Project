package com.watermelon.service;

public class SongSearchService {
	
	public static void songSearch() {
		
		System.out.println("노래 조회용");
		
	}

	//장르별 노래 검색용
	public static void genreSearch() {
		// TODO Auto-generated method stub
		
	}

}

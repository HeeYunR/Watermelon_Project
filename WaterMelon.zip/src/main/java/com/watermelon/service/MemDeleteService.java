package com.watermelon.service;

public class MemDeleteService {

	public static void memDelete() {
		
		System.out.println("관리자_회원 삭제용");
		
	}

}

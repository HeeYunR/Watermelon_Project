package com.watermelon.service;

import java.util.Scanner;

public class MemOutService {

	public static void out() {
		// 회원 탈퇴
		System.out.println("회원 탈퇴 하시겠습니까? (Y/N): ");
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		if (str.equalsIgnoreCase("y")) {
			//회원 정보 삭제(DB에서도 Delete)
			//메인으로 돌아가기
		
		} else if (str.equalsIgnoreCase("n")) {
			
			System.out.println("회원 홈으로 돌아갑니다.");
			
		}
	}

}
